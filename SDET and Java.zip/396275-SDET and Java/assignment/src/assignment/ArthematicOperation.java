package assignment;

public class ArthematicOperation {
	public static void main(String arg[]) { 
        int sum = -5 + 8 * 6; 
        System.out.println("Result " + sum); 
        int sum1 = (55 + 9) % 9; 
        System.out.println("Result " + sum1); 
        int sum2 = 20 + -3 * 5 / 8; 
        System.out.println("Result " + sum2); 
        int sum3 = 5 + 15 / 3 * 2 - 8 % 3; 
        System.out.println("Result " + sum3); 
    } 
} 

