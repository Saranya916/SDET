package assignment;

import java.util.Scanner;

public class sumofthedigits {
	
	    public static void main(String args[])
	    {
	        int m, n, sum = 0;
	        Scanner s = new Scanner(System.in);
	        System.out.print("Input an Integer:");
	        m = s.nextInt();
	        while(m > 0)
	        {
	            n = m % 10;
	            sum = sum + n;
	            m = m / 10;
	        }
	        System.out.println(" The Sum of Digits:"+sum);
	    }

}

