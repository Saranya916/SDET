package task4;

import java.util.Scanner;

public class missingnumber {

	public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n-1];
        for(int i=0;i<n-1;i++){
            a[i] = sc.nextInt();
        }
        int miss_int = -1;  
        Boolean flag = true;
        while(flag){
            for(int i=1;i<n+1;i++){
                for(int temp : a){
                    if(i==temp){
                        miss_int = -1;
                        break;
                    }
                    miss_int = i;
                }
                if(miss_int!=-1){
                    System.out.println("The missed value is:"+miss_int);
                    flag = false;
                    break;
                }
            }
        }
    }
}
