package task1;

import java.util.Scanner;

public class smaller_than_k {

	public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int No_of_Array = sc.nextInt();
        int No_of_Queries = sc.nextInt();
        int[] array = new int[No_of_Array];
        int[] queries = new int[No_of_Queries];
        for(int i=0;i<No_of_Array;i++){
            array[i] = sc.nextInt();
        }
        for(int i=0;i<No_of_Queries;i++){
            queries[i] = sc.nextInt();
        }
        for(int query : queries){
            int result = -1;
            for(int element : array){
                if(result<element && element<query){
                    result = element;
                }
            }
            System.out.println("The result for query "+query+" is "+result);
            
        }
    }
}
