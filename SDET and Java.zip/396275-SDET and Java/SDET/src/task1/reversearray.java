package task1;

public class reversearray {

	public static void main(String[] args) {  
        //Initialize array  
        int [] arr = new int [] {1, 2, 3, 4, 5};  
        System.out.println("Original array: ");  
        for (int m = 0; m < arr.length; m++) {  
            System.out.print(arr[m] + " ");  
        }  
        System.out.println();  
        System.out.println("Array in reverse order: ");  
        //Loop through the array in reverse order  
        for (int m = arr.length-1; m >= 0; m--) {  
            System.out.print(arr[m] + " ");  
        }  
    }  
}  
